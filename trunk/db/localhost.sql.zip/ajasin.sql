-- phpMyAdmin SQL Dump
-- version 2.9.0.2
-- http://www.phpmyadmin.net
-- 
-- Host: localhost
-- Czas wygenerowania: 03 Cze 2008, 19:14
-- Wersja serwera: 4.1.22
-- Wersja PHP: 5.1.4

SET FOREIGN_KEY_CHECKS=0;

SET AUTOCOMMIT=0;
START TRANSACTION;

-- 
-- Baza danych: 'ajasin'
-- 

-- 
-- Zrzut danych tabeli 'SM_CLASS'
-- 

REPLACE INTO SM_CLASS (CLS_ID, CLS_NUMBER, CLS_NUMBER_ALPH, CLS_PER_ID, CLS_DESCRIPTION) VALUES 
(2, 3, 'B', NULL, 'Matematyczna'),
(4, 8, 'A', 98, 'Matematyczno - przyrodnicza'),
(5, 5, 'A', NULL, 'Sportowa'),
(6, 5, 'C', 97, 'humanistyczna'),
(7, 6, 'D', 98, 'Lala');

-- 
-- Zrzut danych tabeli 'SM_CLASSROOM'
-- 

REPLACE INTO SM_CLASSROOM (CLR_ID, CLR_OWNER_PER_ID, CLR_DESCR, CLR_NUMER) VALUES 
(1, NULL, 'Historyczna', 12),
(2, NULL, 'Matematyczna pracownia', 113),
(3, 95, 'Szatanska szkola piekla ]:->', 666),
(86325, NULL, 'Geograficzna', 44),
(86326, NULL, 'Laboratorium', 101),
(86327, NULL, 'Aula', 102),
(86328, NULL, 'Wykładowa mała', 505),
(86329, NULL, 'Wykładowa duża', 13),
(86330, NULL, 'Polska', 88),
(86331, NULL, 'ag', 56),
(86332, NULL, 'ata', 55),
(86333, NULL, 'urygh', 7534);

-- 
-- Zrzut danych tabeli 'SM_DAY'
-- 

REPLACE INTO SM_DAY (DAY_ID, DAY_NAME) VALUES 
(1, 'Poniedziałek'),
(2, 'Wtorek'),
(3, 'Środa'),
(4, 'Czwartek'),
(5, 'Piątek'),
(6, 'Sobota'),
(7, 'Niedziela');

-- 
-- Zrzut danych tabeli 'SM_MESSAGE'
-- 

REPLACE INTO SM_MESSAGE (MSG_ID, MSG_RECP_USR_ID, MSG_SENDER_USR_ID, MSG_SEND_DATE, MSG_BODY, MSG_TOPIC, MSG_PARENT_ID, MSG_CHILD_ID, MSG_RESP_REQ, MSG_READED, MSG_SEVERITY) VALUES 
(26, 15, 15, '2008-05-22 19:46:24', '', 'Jakis mail trza napisac', NULL, NULL, NULL, 1, 2),
(30, 15, 30, '2008-05-23 22:51:31', 'Wazne!', 'Wazne!', NULL, NULL, NULL, 1, 0),
(34, 15, 30, '2008-05-23 23:29:44', 'Wazna wiadomosc z powiadomieniem :-)', 'Wazna wiadomosc :-)', NULL, NULL, NULL, 1, 0),
(36, 15, 30, '2008-05-23 23:31:06', 'Booyah!', 'Kolejna mega wazna wiadomosc!', NULL, NULL, NULL, 1, 0),
(38, 15, 30, '2008-05-23 23:42:38', '', 'Broadcast :-)', NULL, NULL, NULL, 1, 0),
(40, NULL, 30, '2008-05-23 23:42:38', '', 'Broadcast :-)', NULL, NULL, NULL, 0, 0),
(41, NULL, 30, '2008-05-23 23:42:38', '', 'Broadcast :-)', NULL, NULL, NULL, 0, 0),
(44, 15, 30, '2008-05-25 12:26:54', 'Zrob update SVN zanim zaczniesz cos grzebac!', 'Przed edycja zrob update SVN!', NULL, NULL, NULL, 1, 0),
(45, 30, 30, '2008-05-25 12:26:54', 'Zrob update SVN zanim zaczniesz cos grzebac!', 'Przed edycja zrob update SVN!', NULL, NULL, NULL, 1, 0),
(46, 76, 30, '2008-05-25 12:26:54', 'Zrob update SVN zanim zaczniesz cos grzebac!', 'Przed edycja zrob update SVN!', NULL, NULL, NULL, 0, 0),
(47, NULL, 30, '2008-05-25 12:26:54', 'Zrob update SVN zanim zaczniesz cos grzebac!', 'Przed edycja zrob update SVN!', NULL, NULL, NULL, 0, 0),
(48, 15, 15, '2008-05-25 12:44:05', '> Zrob update SVN zanim zaczniesz cos grzebac!\n\n', 'Fwd: Przed edycja zrob update SVN!', NULL, NULL, NULL, 1, 2),
(50, 53, 80, '2008-05-26 13:30:04', 'Proszę się do mnie zgłosić w celu ...', 'Od pana Romana', NULL, NULL, NULL, 1, 0),
(51, 66, 80, '2008-05-26 13:30:05', 'Proszę się do mnie zgłosić w celu ...', 'Od pana Romana', NULL, NULL, NULL, 0, 0),
(52, 81, 80, '2008-05-26 13:30:05', 'Proszę się do mnie zgłosić w celu ...', 'Od pana Romana', NULL, NULL, NULL, 1, 0),
(53, 53, 81, '2008-05-26 13:32:46', '> Proszę się do mnie zgłosić w celu ...\n\nfwd', 'Fwd: Od pana Romana', NULL, NULL, NULL, 1, 0),
(54, 66, 81, '2008-05-26 13:32:46', '> Proszę się do mnie zgłosić w celu ...\n\nfwd', 'Fwd: Od pana Romana', NULL, NULL, NULL, 0, 0),
(55, 81, 81, '2008-05-26 13:32:47', '> Proszę się do mnie zgłosić w celu ...\n\nfwd', 'Fwd: Od pana Romana', NULL, NULL, NULL, 1, 0),
(56, 15, 15, '2008-05-27 22:12:54', 'asd', 'ALERT', NULL, NULL, NULL, 1, 0),
(57, 30, 15, '2008-05-27 22:12:54', 'asd', 'ALERT', NULL, NULL, NULL, 1, 0),
(58, 76, 15, '2008-05-27 22:12:55', 'asd', 'ALERT', NULL, NULL, NULL, 0, 0),
(59, 15, 15, '2008-05-27 22:13:21', '> asd\n\npiszesz do siebie? co za schizofrenia :P', 'Re: ALERT', NULL, NULL, NULL, 1, 2),
(60, 30, 15, '2008-05-27 22:32:11', 'Pozno juz', '22:32', NULL, NULL, NULL, 1, 0),
(61, 15, 30, '2008-05-27 22:32:51', 'A, a tu minutke pozniej juz :-)', '22:33', NULL, NULL, NULL, 1, 0);

-- 
-- Zrzut danych tabeli 'SM_NOTE'
-- 

REPLACE INTO SM_NOTE (NOT_ID, NOT_NOTE, NOT_P2C_ID, NOT_SUB_ID, NOT_TCH_PER_ID, NOT_COMMENT, NOT_DATE) VALUES 
(32, '4-', 38, 8, 24, '', '2008-05-27 22:39:22'),
(33, '3+', 38, 8, 24, '', '2008-05-27 22:39:28'),
(34, '5-', 39, 8, 24, '', '2008-05-27 22:39:36'),
(35, '1', 39, 8, 24, '', '2008-05-27 22:39:38'),
(36, '6', 37, 8, 24, '', '2008-05-27 22:39:50'),
(37, '3-', 37, 8, 24, '', '2008-05-27 22:39:55'),
(38, '20/30', 38, 30, 24, '', '2008-05-27 22:40:13'),
(39, '30/30', 39, 30, 24, '', '2008-05-27 22:40:24'),
(40, '22/30', 37, 30, 24, '', '2008-05-27 22:40:39'),
(41, 'zal.', 42, 13, 24, '', '2008-05-27 22:42:51'),
(42, 'zal.', 40, 13, 24, '', '2008-05-27 22:43:00'),
(43, 'zal', 41, 13, 24, 'brak stroju!', '2008-05-27 22:43:12');

-- 
-- Zrzut danych tabeli 'SM_PERSON'
-- 

REPLACE INTO SM_PERSON (PER_ID, PER_NAME, PER_SURNAME, PER_PESEL, PER_NIP, PER_PHONE, PER_ADRESS, PER_EMAIL) VALUES 
(24, 'Andrzej', 'Jasiński', '0', '343423431124', '234324', 'ZXzxczdsc', 'jasiu@'),
(45, 'Tomasz', 'Huczek', '123123123123', '123123', '123123', 'Krakow', 'thuczek@gmail.com'),
(70, 'Mariusz', 'Nowak', '876', '876', '876', 'kbl', ''),
(83, 'Tomus', 'Uczeński', '123', '123', '123', 'asd', 'asd'),
(93, 'Szczepan', 'Albenty', '987', '987', '987', '987', ''),
(95, 'Piotr', 'Balys', '987', '987', '987', '987', ''),
(97, 'Sławomir', 'Suchy', '79864634', '46213579', '35798646', 'ul. Mokra 99', 'suchy@mokry.pl'),
(98, 'Roman', 'Kostrzewski', '234012342', '122342109', NULL, 'ul. Krzewów 14', 'roman@one.pl'),
(100, 'Tomasz', 'Kolorek', '6476858', '539539675', NULL, 'kolorkowa 129', 'klk@klk.kl'),
(102, 'Jurek', 'Polaczek', '111', '111', NULL, 'aaa', 'aaa'),
(103, 'Andrzej', 'August', '999', '999', NULL, 'iii', 'fff'),
(104, 'Jakub', 'Kosmaty', '111', '111', NULL, 'ppp', 'ppp'),
(105, 'Wacław', 'Wuefski', '11', '11', NULL, 'o', 'o@o2.pl'),
(106, 'Paweł', 'Profesorski', '1111', '11', NULL, 'a', 'a@op.pl'),
(107, 'Igor', 'Igorski', '0', '0', NULL, 'pppp', 'PPP'),
(108, 'Ma', 'Ala', '123', '123', '123', 'Kota', 'dsa');

-- 
-- Zrzut danych tabeli 'SM_PERSON2CLASS'
-- 

REPLACE INTO SM_PERSON2CLASS (P2C_ID, P2C_PER_ID, P2C_CLS_ID) VALUES 
(37, 70, 6),
(38, 100, 6),
(39, 104, 6),
(40, 102, 5),
(41, 83, 5),
(42, 70, 5);

-- 
-- Zrzut danych tabeli 'SM_PERSON_NOTES'
-- 


-- 
-- Zrzut danych tabeli 'SM_RING'
-- 

REPLACE INTO SM_RING (RNG_ID, RNG_TIME) VALUES 
(1, '07:10:00'),
(2, '08:00:00'),
(3, '08:50:00'),
(4, '09:45:00'),
(5, '10:55:00'),
(6, '12:20:00'),
(7, '13:35:00'),
(8, '14:25:00'),
(9, '15:15:00'),
(10, '16:25:00'),
(11, '17:20:00'),
(12, '00:00:00'),
(13, '00:00:00'),
(14, '00:00:00'),
(15, '00:00:00'),
(16, '00:00:00'),
(17, '00:00:00'),
(18, '00:00:00');

-- 
-- Zrzut danych tabeli 'SM_ROLE'
-- 

REPLACE INTO SM_ROLE (ROL_ID, ROL_NAME) VALUES 
(1, 'Admin'),
(2, 'Dyrektor'),
(3, 'Nauczyciel'),
(4, 'Uczen');

-- 
-- Zrzut danych tabeli 'SM_SCHEDULE'
-- 

REPLACE INTO SM_SCHEDULE (SCH_ID, SCH_DAY_ID, SCH_RNG_ID, SCH_CLS_ID, SCH_CLR_ID, SCH_TCH_PER_ID, SCH_SUB_ID) VALUES 
(4, 1, 1, 2, 2, 97, 7),
(5, 1, 2, 2, 1, NULL, 9),
(6, 1, 3, 2, 3, 107, 9),
(7, 1, 4, 2, 1, 97, 7),
(8, 1, 5, 2, 3, 97, 7),
(9, 2, 1, 2, 3, 107, 9),
(10, 2, 2, 2, 3, 97, 7),
(11, 2, 3, 2, 2, 107, 9),
(12, 1, 1, 4, 3, NULL, 9),
(13, 1, 2, 2, 86326, 107, 9),
(14, 1, 6, 2, 1, 97, 7),
(15, 1, 7, 2, 2, 107, 9),
(16, 1, 8, 2, 2, 97, 7),
(17, 5, 1, 2, 2, 97, 8),
(18, 1, 9, 2, 1, 95, 12),
(19, 4, 4, 2, 2, 97, 7),
(20, 2, 5, 2, 1, 97, 7),
(21, 4, 5, 2, 3, 98, 30),
(22, 1, 2, 6, 3, 98, 30),
(23, 1, 3, 6, 86327, 97, 8),
(24, 1, 1, 5, 86325, 105, 13),
(25, 1, 2, 5, 86325, 105, 13),
(26, 1, 3, 5, 2, 105, 15),
(27, 1, 4, 5, 86325, 95, 18),
(28, 1, 5, 5, 1, 105, 14),
(29, 1, 6, 5, 2, 98, 30),
(30, 1, 7, 5, 86326, 97, 7),
(31, 2, 1, 5, 2, 95, 12),
(32, 2, 2, 5, 1, 105, 13),
(33, 2, 3, 5, 1, 105, 14),
(34, 2, 4, 5, 1, 98, 30),
(35, 2, 5, 5, 2, 98, 30),
(36, 2, 6, 5, 1, 97, 8),
(37, 2, 4, 2, 2, 97, 8),
(38, 3, 4, 2, 1, 97, 7);

-- 
-- Zrzut danych tabeli 'SM_SUBJECT'
-- 

REPLACE INTO SM_SUBJECT (SUB_ID, SUB_NAME) VALUES 
(7, 'Biologia'),
(8, 'Chemia'),
(9, 'Geografia'),
(12, 'Muzyka'),
(13, 'WF'),
(14, 'Podstawy Elektrotechniki'),
(15, 'Plastyka'),
(16, 'Fizyka'),
(17, 'Analiza matematyczna'),
(18, 'Algebra'),
(19, 'Informatyka'),
(20, 'Elektronika'),
(21, 'Język hiszpański'),
(30, 'Religioznawstwo'),
(31, 'Etyka'),
(32, 'Język polski');

-- 
-- Zrzut danych tabeli 'SM_TEACHER'
-- 

REPLACE INTO SM_TEACHER (TCH_ID, TCH_PER_ID, TCH_SUB_ID) VALUES 
(42, 95, 12),
(43, 95, 18),
(44, 97, 7),
(45, 98, 30),
(46, 98, 31),
(47, 97, 8),
(48, 105, 13),
(49, 105, 14),
(50, 105, 15),
(51, 106, 21),
(52, 106, 19),
(53, 106, 20),
(54, 107, 9),
(55, 107, 16);

-- 
-- Zrzut danych tabeli 'SM_USER'
-- 

REPLACE INTO SM_USER (USR_ID, USR_LOGIN, USR_PASSWD, USR_PER_ID, USR_ROL_ID, USR_ISLOGGED) VALUES 
(15, 'jasiu', 'asd', 24, 1, 0),
(30, 'huczek', 'asd', 45, 1, 0),
(53, 'kb', '', 70, 4, 0),
(66, 'uczen', '', 83, 4, 0),
(76, '987', '', 93, 1, 0),
(77, '243234', '', 95, 3, 0),
(79, 'jb', '', 97, 3, 0),
(80, 'rkos', 'rkos', 98, 3, 0),
(81, 'klk', '', 100, 4, 0),
(82, 'jurek', '', 102, 4, 0),
(83, 'and', '', 103, 4, 0),
(84, 'jak', '', 104, 4, 0),
(85, 'wwr', '', 105, 3, 0),
(86, 'ppp', '', 106, 3, 0),
(87, 'wqw', '', 107, 3, 0),
(88, 'ala', '', 108, 4, 0);

SET FOREIGN_KEY_CHECKS=1;

COMMIT;
